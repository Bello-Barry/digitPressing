LB PRESSING : kit d'identité visuelle
Couleurs : bleu nuit #041C4C, or #FFC72C a #F5A300, bleu royal #0B5CE1, blanc #FFFFFF.
icons/icon-192.png, icon-512.png : icônes d'application (any)
icons/icon-maskable-512.png : icône adaptative Android (contenu dans la zone de sécurité)
icons/apple-touch-icon.png (180x180), favicon.ico, favicon-32.png
icons/icon-source-1024.png : source carrée 1024 pour régénérer d'autres tailles
logo/logo-mark.png : monogramme LB transparent (fonds sombres)
logo/logo-horizontal-light.png (fond blanc), logo-horizontal-dark.png (fond bleu nuit)
og/og-image.png : image de partage 1200x630
